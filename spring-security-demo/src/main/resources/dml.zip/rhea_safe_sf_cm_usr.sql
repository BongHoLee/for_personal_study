create table sf_cm_usr
(
    usr_id           varchar(20)  not null
        constraint sf_cm_usr_pk
            primary key,
    usr_nm           varchar(50)  not null,
    usr_sts_clc      varchar(1)   not null,
    pwd_ctnt         varchar(500) not null,
    sec_key          varchar(200) not null,
    pwd_err_nts      numeric(3),
    pwd_chg_necs_yn  varchar(1),
    pwd_lt_chg_dtm   varchar(14),
    login_ip_verf_yn varchar(1)   not null,
    login_ip         varchar(15),
    dptm_id          varchar(10),
    dptm_nm          varchar(50),
    mbphn_pno        varchar(15),
    offc_pno         varchar(15),
    email            varchar(50),
    reg_usr_id       varchar(20)  not null,
    reg_stm          date         not null,
    chg_usr_id       varchar(20)  not null,
    chg_stm          date         not null
);

alter table sf_cm_usr
    owner to safe;

INSERT INTO safe.sf_cm_usr (usr_id, usr_nm, usr_sts_clc, pwd_ctnt, sec_key, pwd_err_nts, pwd_chg_necs_yn, pwd_lt_chg_dtm, login_ip_verf_yn, login_ip, dptm_id, dptm_nm, mbphn_pno, offc_pno, email, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('user', 'user', '1', 'b5dc62604f63508735e9b0fc2d0b56e41398945d3cabc4a8e41b09f606977b43', 'qgNoT9I/gUaYl+vkKIFh8CeoISVpkc/VTBmNaR93Ay1LHuiK/mAgrqnqDBt7fub/cjBSQK7Hv3+T2lKvyceytg==', 0, '0', '20210827155600', '1', null, null, null, '01064835336', '027086266', 'user@koreacb.com', 'INIT', '2020-01-01', 'SYSTEM', '2021-08-27');
INSERT INTO safe.sf_cm_usr (usr_id, usr_nm, usr_sts_clc, pwd_ctnt, sec_key, pwd_err_nts, pwd_chg_necs_yn, pwd_lt_chg_dtm, login_ip_verf_yn, login_ip, dptm_id, dptm_nm, mbphn_pno, offc_pno, email, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('testuser', 'test', '3', '3f0343c59975f65566e73be032153aa43bc7ca996117c64bfd8773a6a4eff933', 'RV6od8ocBNKF5mGlQ2EhX6ApasOjWtyxBgGO7qc0TuQOHiKvOp369dM9P3b5f2ZtGGy+4AzVIlw+jMm5MRcGWg==', 3, '1', '20210827155443', '1', '', '', '', '', '', 'leebongho9204@gmail.com', 'admin', '2021-08-27', 'SYSTEM', '2021-08-27');
INSERT INTO safe.sf_cm_usr (usr_id, usr_nm, usr_sts_clc, pwd_ctnt, sec_key, pwd_err_nts, pwd_chg_necs_yn, pwd_lt_chg_dtm, login_ip_verf_yn, login_ip, dptm_id, dptm_nm, mbphn_pno, offc_pno, email, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('testjh', 'testjh', '1', 'f2ee6b855741a9f71cfd6adcd1f1b869f1364dd5a8ee097b3b039202cfc72f09', 'nEVXs218lmRSUrqwE+oZtKIdq70YwB8Aqvd/wFEAQRlrehCHh2498WLMMXQe12eDh40o6zemmSrjFQtfItS9rg==', 0, '0', '20220120164210', '1', '', '', '', '01093965661', '', 'jh.kim@koreacb.com', 'admin', '2022-01-20', 'SYSTEM', '2022-01-20');
INSERT INTO safe.sf_cm_usr (usr_id, usr_nm, usr_sts_clc, pwd_ctnt, sec_key, pwd_err_nts, pwd_chg_necs_yn, pwd_lt_chg_dtm, login_ip_verf_yn, login_ip, dptm_id, dptm_nm, mbphn_pno, offc_pno, email, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('manager', 'manager', '1', '2a6873623a8f3065765d0683ab54c2d6e2bdffa3c3e296dbeb9e6ae50e0ef288', 'MYOIjxjIQPjHdkXTjqZJaemUUde4ack3XUMeOk38qGnmLlwMu4n1G2ut7wLBoNL8BpSaN9ToBks7tqz01A+fRQ==', 0, '0', '20220121113615', '1', null, null, null, '01064835336', '027086266', 'manager@koreacb.com', 'INIT', '2020-01-01', 'SYSTEM', '2022-01-21');
INSERT INTO safe.sf_cm_usr (usr_id, usr_nm, usr_sts_clc, pwd_ctnt, sec_key, pwd_err_nts, pwd_chg_necs_yn, pwd_lt_chg_dtm, login_ip_verf_yn, login_ip, dptm_id, dptm_nm, mbphn_pno, offc_pno, email, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('admin', 'administrator', '1', '8804039de3ae900a7afe94099ccade64f28e479d7c03fb51513d384dc6a4f14b', 'Okzld7eCkGfDRFIN/1p78ZE2+05UZGPj5sESV7nW25kemdkOEc5O55rX6bEJSbTpPOjkWb4lVxYr30JwT07UdA==', 0, '0', '20220209120239', '1', null, null, null, '01012345678', '021231234', 'admin@kcb4u.com', 'INIT', '2020-01-01', 'SYSTEM', '2022-02-09');