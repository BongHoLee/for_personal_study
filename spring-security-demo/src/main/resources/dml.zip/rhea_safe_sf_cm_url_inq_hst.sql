create table sf_cm_url_inq_hst
(
    crt_dtm    varchar(255) not null,
    url_ctnt   varchar(255) not null,
    usr_id     varchar(255) not null,
    chg_stm    timestamp,
    chg_usr_id varchar(255),
    menu_id    varchar(255),
    reg_stm    timestamp,
    reg_usr_id varchar(255),
    constraint sf_cm_url_inq_hst_pkey
        primary key (crt_dtm, url_ctnt, usr_id)
);

alter table sf_cm_url_inq_hst
    owner to safe;

