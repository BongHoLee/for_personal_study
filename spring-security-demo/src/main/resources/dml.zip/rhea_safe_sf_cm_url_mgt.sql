create table sf_cm_url_mgt
(
    url_ctnt       varchar(50) not null
        constraint sf_cm_url_pk
            primary key,
    url_nm         varchar(30),
    menu_id        varchar(20),
    repo_lst       varchar(500),
    inq_hst_reg_yn varchar(1),
    chg_hst_reg_yn varchar(1),
    reg_usr_id     varchar(20),
    reg_stm        date,
    chg_usr_id     varchar(20),
    chg_stm        date
);

alter table sf_cm_url_mgt
    owner to safe;

