create table sf_cm_cmd
(
    cmd_id     varchar(50) not null
        constraint sf_cm_exec_pk
            primary key,
    cmd_nm     varchar(50) not null,
    menu_id    varchar(20) not null,
    reg_usr_id varchar(20) not null,
    reg_stm    date        not null,
    chg_usr_id varchar(20) not null,
    chg_stm    date        not null
);

alter table sf_cm_cmd
    owner to safe;

INSERT INTO safe.sf_cm_cmd (cmd_id, cmd_nm, menu_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('comCdDeleteBtn', '공통코드삭제', '53', 'INIT', '2020-01-01', 'admin', '2021-07-29');
INSERT INTO safe.sf_cm_cmd (cmd_id, cmd_nm, menu_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('comCdNewBtn', '공통코드신규', '53', 'INIT', '2020-01-01', 'admin', '2021-07-29');
INSERT INTO safe.sf_cm_cmd (cmd_id, cmd_nm, menu_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('comCdTpDeleteBtn', '공통코드유형삭제', '53', 'INIT', '2020-01-01', 'admin', '2021-07-29');
INSERT INTO safe.sf_cm_cmd (cmd_id, cmd_nm, menu_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('comCdTpNewBtn', '공통코드유형신규', '53', 'INIT', '2020-01-01', 'admin', '2021-07-29');
INSERT INTO safe.sf_cm_cmd (cmd_id, cmd_nm, menu_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('comCdTpUpdateBtn', '공통코드유형수정', '53', 'INIT', '2020-01-01', 'admin', '2021-07-29');
INSERT INTO safe.sf_cm_cmd (cmd_id, cmd_nm, menu_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('comCdUpdateBtn', '공통코드수정', '53', 'INIT', '2020-01-01', 'admin', '2021-07-29');
INSERT INTO safe.sf_cm_cmd (cmd_id, cmd_nm, menu_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('rulePreConditionDeleteBtn', '룰선행조건삭제', '63', 'INIT', '2020-01-01', 'admin', '2021-07-29');
INSERT INTO safe.sf_cm_cmd (cmd_id, cmd_nm, menu_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('rulePreConditionNewBtn', '룰선행조건신규', '63', 'INIT', '2020-01-01', 'admin', '2021-07-29');
INSERT INTO safe.sf_cm_cmd (cmd_id, cmd_nm, menu_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('rulePreConditionUpdateBtn', '룰선행조건수정', '63', 'INIT', '2020-01-01', 'admin', '2021-07-29');
INSERT INTO safe.sf_cm_cmd (cmd_id, cmd_nm, menu_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('ruleApprovalBtn', '룰승인', '30', 'INIT', '2020-01-01', 'admin', '2021-07-29');
INSERT INTO safe.sf_cm_cmd (cmd_id, cmd_nm, menu_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('ruleRejectBtn', '룰반려', '30', 'INIT', '2020-01-01', 'admin', '2021-07-29');