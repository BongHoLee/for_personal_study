create table sf_cm_svr_mgt
(
    svr_id        varchar(50) not null
        constraint sf_cm_svr_mgt_pk
            primary key,
    svr_tp_clc    varchar(2),
    svr_nm        varchar(50),
    svr_ip        varchar(15),
    scrn_prnt_seq numeric(3),
    reg_usr_id    varchar(20),
    reg_stm       date,
    chg_usr_id    varchar(20),
    chg_stm       date
);

alter table sf_cm_svr_mgt
    owner to safe;

INSERT INTO safe.sf_cm_svr_mgt (svr_id, svr_tp_clc, svr_nm, svr_ip, scrn_prnt_seq, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('APDK01', '01', 'AP01', 'safe-fds', 1, 'INIT', '2020-01-01', 'INIT', '2020-01-01');