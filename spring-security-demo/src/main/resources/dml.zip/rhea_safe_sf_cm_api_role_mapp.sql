create table sf_cm_api_role_mapp
(
    api_id     varchar(50) not null,
    role_id    varchar(20) not null,
    reg_usr_id varchar(20) not null,
    reg_stm    date        not null,
    chg_usr_id varchar(20) not null,
    chg_stm    date        not null,
    constraint sf_cm_api_role_mapp_pk
        primary key (api_id, role_id)
);

alter table sf_cm_api_role_mapp
    owner to safe;

INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('11', '1', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('11', '2', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('12', '1', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('12', '2', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('13', '1', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('13', '2', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('14', '1', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('14', '2', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('15', '1', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('15', '2', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('16', '1', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('16', '2', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('17', '1', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('17', '2', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('18', '1', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('18', '2', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('19', '1', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('19', '2', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('20', '1', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('20', '2', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('21', '1', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('21', '2', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('1', '1', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('1', '2', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('10', '1', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('10', '2', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('2', '1', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('2', '2', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('3', '1', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('3', '2', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('4', '1', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('4', '2', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('5', '1', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('5', '2', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('6', '1', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('6', '2', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('7', '1', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('7', '2', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('8', '1', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('8', '2', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('9', '1', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('9', '2', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('22', '1', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('22', '2', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('23', '1', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('23', '2', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('24', '1', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('24', '2', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('25', '1', 'INIT', '2021-08-27', 'INIT', '2021-08-27');
INSERT INTO safe.sf_cm_api_role_mapp (api_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('25', '2', 'INIT', '2021-08-27', 'INIT', '2021-08-27');