create table sf_cm_api
(
    api_id        varchar(20)  not null
        constraint sf_cm_api_pk
            primary key,
    api_nm        varchar(100),
    api_tp_clc    varchar(1)   not null,
    api_exec_clc  varchar(1)   not null,
    api_addr_ctnt varchar(255) not null,
    menu_id       varchar(20)  not null,
    use_yn        varchar(1)   not null,
    hst_reg_yn    varchar(1)   not null,
    reg_usr_id    varchar(20)  not null,
    reg_stm       date         not null,
    chg_usr_id    varchar(20)  not null,
    chg_stm       date         not null
);

alter table sf_cm_api
    owner to safe;

INSERT INTO safe.sf_cm_api (api_id, api_nm, api_tp_clc, api_exec_clc, api_addr_ctnt, menu_id, use_yn, hst_reg_yn, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('1', '사용자목록조회', '1', '1', '/v1/api/user', '', 'Y', '1', 'INIT', '2021-08-23', 'INIT', '2021-08-23');
INSERT INTO safe.sf_cm_api (api_id, api_nm, api_tp_clc, api_exec_clc, api_addr_ctnt, menu_id, use_yn, hst_reg_yn, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('10', '사용자삭제', '1', '3', '/v1/api/user/{usrId}', '', 'Y', '1', 'INIT', '2021-08-23', 'INIT', '2021-08-23');
INSERT INTO safe.sf_cm_api (api_id, api_nm, api_tp_clc, api_exec_clc, api_addr_ctnt, menu_id, use_yn, hst_reg_yn, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('2', '유저정보조회', '1', '1', '/v1/api/user/{userId}', '', 'Y', '1', 'INIT', '2021-08-23', 'INIT', '2021-08-23');
INSERT INTO safe.sf_cm_api (api_id, api_nm, api_tp_clc, api_exec_clc, api_addr_ctnt, menu_id, use_yn, hst_reg_yn, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('3', '유저정보조회', '1', '1', '/v1/api/user/profile/{userId}', '', 'Y', '1', 'INIT', '2021-08-23', 'INIT', '2021-08-23');
INSERT INTO safe.sf_cm_api (api_id, api_nm, api_tp_clc, api_exec_clc, api_addr_ctnt, menu_id, use_yn, hst_reg_yn, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('4', '사용자생성', '1', '2', '/v1/api/user', '', 'Y', '1', 'INIT', '2021-08-23', 'INIT', '2021-08-23');
INSERT INTO safe.sf_cm_api (api_id, api_nm, api_tp_clc, api_exec_clc, api_addr_ctnt, menu_id, use_yn, hst_reg_yn, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('5', '사용자수정', '1', '3', '/v1/api/user/{usrId}', '', 'Y', '1', 'INIT', '2021-08-23', 'INIT', '2021-08-23');
INSERT INTO safe.sf_cm_api (api_id, api_nm, api_tp_clc, api_exec_clc, api_addr_ctnt, menu_id, use_yn, hst_reg_yn, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('6', '사용자잠금해제', '1', '3', '/v1/api/user/lock-clear', '', 'Y', '1', 'INIT', '2021-08-23', 'INIT', '2021-08-23');
INSERT INTO safe.sf_cm_api (api_id, api_nm, api_tp_clc, api_exec_clc, api_addr_ctnt, menu_id, use_yn, hst_reg_yn, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('7', '사용자비밀번호변경', '1', '3', '/v1/api/user/password-change', '', 'Y', '1', 'INIT', '2021-08-23', 'INIT', '2021-08-23');
INSERT INTO safe.sf_cm_api (api_id, api_nm, api_tp_clc, api_exec_clc, api_addr_ctnt, menu_id, use_yn, hst_reg_yn, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('8', '사용자비밀번호초기화', '1', '3', '/v1/api/user/password-reset/{usrId}', '', 'Y', '1', 'INIT', '2021-08-23', 'INIT', '2021-08-23');
INSERT INTO safe.sf_cm_api (api_id, api_nm, api_tp_clc, api_exec_clc, api_addr_ctnt, menu_id, use_yn, hst_reg_yn, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('9', '사용자수정', '1', '3', '/v1/api/user/profile/{usrId}', '', 'Y', '1', 'INIT', '2021-08-23', 'INIT', '2021-08-23');
INSERT INTO safe.sf_cm_api (api_id, api_nm, api_tp_clc, api_exec_clc, api_addr_ctnt, menu_id, use_yn, hst_reg_yn, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('11', '권한목록조회', '1', '1', '/v1/api/role', '', 'Y', '1', 'INIT', '2021-08-23', 'INIT', '2021-08-23');
INSERT INTO safe.sf_cm_api (api_id, api_nm, api_tp_clc, api_exec_clc, api_addr_ctnt, menu_id, use_yn, hst_reg_yn, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('12', '유저역할매핑건수조회', '1', '1', '/v1/api/role/{roleId}/user-role-count', '', 'Y', '1', 'INIT', '2021-08-23', 'INIT', '2021-08-23');
INSERT INTO safe.sf_cm_api (api_id, api_nm, api_tp_clc, api_exec_clc, api_addr_ctnt, menu_id, use_yn, hst_reg_yn, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('13', '권한목록메뉴이름조회', '1', '1', '/v1/api/role/menu', '', 'Y', '1', 'INIT', '2021-08-23', 'INIT', '2021-08-23');
INSERT INTO safe.sf_cm_api (api_id, api_nm, api_tp_clc, api_exec_clc, api_addr_ctnt, menu_id, use_yn, hst_reg_yn, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('14', '새로운권한생성', '1', '2', '/v1/api/role', '', 'Y', '1', 'INIT', '2021-08-23', 'INIT', '2021-08-23');
INSERT INTO safe.sf_cm_api (api_id, api_nm, api_tp_clc, api_exec_clc, api_addr_ctnt, menu_id, use_yn, hst_reg_yn, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('15', '메뉴역할매핑수정', '1', '2', '/v1/api/role/{roleId}/menu-role', '', 'Y', '1', 'INIT', '2021-08-23', 'INIT', '2021-08-23');
INSERT INTO safe.sf_cm_api (api_id, api_nm, api_tp_clc, api_exec_clc, api_addr_ctnt, menu_id, use_yn, hst_reg_yn, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('16', '권한수정', '1', '3', '/v1/api/role/{roleId}', '', 'Y', '1', 'INIT', '2021-08-23', 'INIT', '2021-08-23');
INSERT INTO safe.sf_cm_api (api_id, api_nm, api_tp_clc, api_exec_clc, api_addr_ctnt, menu_id, use_yn, hst_reg_yn, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('17', '권한삭제', '1', '4', '/v1/api/role/{roleId}', '', 'Y', '1', 'INIT', '2021-08-23', 'INIT', '2021-08-23');
INSERT INTO safe.sf_cm_api (api_id, api_nm, api_tp_clc, api_exec_clc, api_addr_ctnt, menu_id, use_yn, hst_reg_yn, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('18', '메뉴목록트리조회', '1', '1', '/v1/api/menu', '', 'Y', '1', 'INIT', '2021-08-23', 'INIT', '2021-08-23');
INSERT INTO safe.sf_cm_api (api_id, api_nm, api_tp_clc, api_exec_clc, api_addr_ctnt, menu_id, use_yn, hst_reg_yn, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('19', '새로운메뉴생성', '1', '2', '/v1/api/menu', '', 'Y', '1', 'INIT', '2021-08-23', 'INIT', '2021-08-23');
INSERT INTO safe.sf_cm_api (api_id, api_nm, api_tp_clc, api_exec_clc, api_addr_ctnt, menu_id, use_yn, hst_reg_yn, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('20', '메뉴수정', '1', '3', '/v1/api/menu/{menuId}', '', 'Y', '1', 'INIT', '2021-08-23', 'INIT', '2021-08-23');
INSERT INTO safe.sf_cm_api (api_id, api_nm, api_tp_clc, api_exec_clc, api_addr_ctnt, menu_id, use_yn, hst_reg_yn, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('21', '메뉴삭제', '1', '4', '/v1/api/menu/{menuId}', '', 'Y', '1', 'INIT', '2021-08-23', 'INIT', '2021-08-23');
INSERT INTO safe.sf_cm_api (api_id, api_nm, api_tp_clc, api_exec_clc, api_addr_ctnt, menu_id, use_yn, hst_reg_yn, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('22', '로그인정보조회', '1', '1', '/v1/api/signin/getUserInfo', '', 'Y', '1', 'INIT', '2021-08-23', 'INIT', '2021-08-23');
INSERT INTO safe.sf_cm_api (api_id, api_nm, api_tp_clc, api_exec_clc, api_addr_ctnt, menu_id, use_yn, hst_reg_yn, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('23', '대시보드서버조회', '1', '1', '/v1/api/dashboard/server', '', 'Y', '1', 'INIT', '2021-08-23', 'INIT', '2021-08-23');
INSERT INTO safe.sf_cm_api (api_id, api_nm, api_tp_clc, api_exec_clc, api_addr_ctnt, menu_id, use_yn, hst_reg_yn, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('24', '대시보드정보조회', '1', '1', '/v1/api/dashboard/term', '', 'Y', '1', 'INIT', '2021-08-23', 'INIT', '2021-08-23');
INSERT INTO safe.sf_cm_api (api_id, api_nm, api_tp_clc, api_exec_clc, api_addr_ctnt, menu_id, use_yn, hst_reg_yn, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('25', '대시보드데이터조회', '1', '1', '/v1/api/dashboard/manage', '', 'Y', '1', 'INIT', '2021-08-23', 'INIT', '2021-08-23');