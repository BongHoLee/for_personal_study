create table sf_cm_cmd_role_mapp
(
    cmd_id     varchar(50) not null,
    role_id    varchar(20) not null,
    reg_usr_id varchar(20) not null,
    reg_stm    date        not null,
    chg_usr_id varchar(20) not null,
    chg_stm    date        not null,
    constraint sf_cm_exec_role_mapp_pk
        primary key (cmd_id, role_id)
);

alter table sf_cm_cmd_role_mapp
    owner to safe;

INSERT INTO safe.sf_cm_cmd_role_mapp (cmd_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('comCdDeleteBtn', '1', 'admin', '2021-07-29', 'admin', '2021-07-29');
INSERT INTO safe.sf_cm_cmd_role_mapp (cmd_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('comCdNewBtn', '1', 'admin', '2021-07-29', 'admin', '2021-07-29');
INSERT INTO safe.sf_cm_cmd_role_mapp (cmd_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('comCdTpDeleteBtn', '1', 'admin', '2021-07-29', 'admin', '2021-07-29');
INSERT INTO safe.sf_cm_cmd_role_mapp (cmd_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('comCdTpNewBtn', '1', 'admin', '2021-07-29', 'admin', '2021-07-29');
INSERT INTO safe.sf_cm_cmd_role_mapp (cmd_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('comCdTpUpdateBtn', '1', 'admin', '2021-07-29', 'admin', '2021-07-29');
INSERT INTO safe.sf_cm_cmd_role_mapp (cmd_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('comCdUpdateBtn', '1', 'admin', '2021-07-29', 'admin', '2021-07-29');
INSERT INTO safe.sf_cm_cmd_role_mapp (cmd_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('rulePreConditionDeleteBtn', '1', 'admin', '2021-07-29', 'admin', '2021-07-29');
INSERT INTO safe.sf_cm_cmd_role_mapp (cmd_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('rulePreConditionDeleteBtn', '2', 'admin', '2021-07-29', 'admin', '2021-07-29');
INSERT INTO safe.sf_cm_cmd_role_mapp (cmd_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('rulePreConditionNewBtn', '1', 'admin', '2021-07-29', 'admin', '2021-07-29');
INSERT INTO safe.sf_cm_cmd_role_mapp (cmd_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('rulePreConditionNewBtn', '2', 'admin', '2021-07-29', 'admin', '2021-07-29');
INSERT INTO safe.sf_cm_cmd_role_mapp (cmd_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('rulePreConditionUpdateBtn', '1', 'admin', '2021-07-29', 'admin', '2021-07-29');
INSERT INTO safe.sf_cm_cmd_role_mapp (cmd_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('rulePreConditionUpdateBtn', '2', 'admin', '2021-07-29', 'admin', '2021-07-29');
INSERT INTO safe.sf_cm_cmd_role_mapp (cmd_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('ruleApprovalBtn', '1', 'admin', '2021-07-29', 'admin', '2021-07-29');
INSERT INTO safe.sf_cm_cmd_role_mapp (cmd_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('ruleApprovalBtn', '2', 'admin', '2021-07-29', 'admin', '2021-07-29');
INSERT INTO safe.sf_cm_cmd_role_mapp (cmd_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('ruleRejectBtn', '1', 'admin', '2021-07-29', 'admin', '2021-07-29');
INSERT INTO safe.sf_cm_cmd_role_mapp (cmd_id, role_id, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('ruleRejectBtn', '2', 'admin', '2021-07-29', 'admin', '2021-07-29');