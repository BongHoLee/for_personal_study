create table sf_cm_role
(
    role_id    varchar(20)  not null
        constraint sf_cm_role_pk
            primary key,
    role_nm    varchar(100) not null,
    expln_ctnt varchar(100),
    reg_usr_id varchar(20)  not null,
    reg_stm    date         not null,
    chg_usr_id varchar(20)  not null,
    chg_stm    date         not null
);

alter table sf_cm_role
    owner to safe;

INSERT INTO safe.sf_cm_role (role_id, role_nm, expln_ctnt, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('1', '운영자', '운영자', 'INIT', '2020-01-01', 'INIT', '2020-01-01');
INSERT INTO safe.sf_cm_role (role_id, role_nm, expln_ctnt, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('2', '관리자', '관리자', 'INIT', '2020-01-01', 'INIT', '2020-01-01');
INSERT INTO safe.sf_cm_role (role_id, role_nm, expln_ctnt, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('3', '사용자', '사용자', 'INIT', '2020-01-01', 'admin', '2021-08-19');