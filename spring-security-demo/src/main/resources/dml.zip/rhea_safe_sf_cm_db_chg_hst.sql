create table sf_cm_db_chg_hst
(
    tbl_id        varchar(20) not null,
    crt_dtm       varchar(14) not null,
    col_id        varchar(20) not null,
    bf_data_ctnt  varchar(1000),
    chg_data_ctnt varchar(1000),
    reg_usr_id    varchar(20) not null,
    reg_stm       date        not null,
    chg_usr_id    varchar(20) not null,
    chg_stm       date        not null
);

alter table sf_cm_db_chg_hst
    owner to safe;

