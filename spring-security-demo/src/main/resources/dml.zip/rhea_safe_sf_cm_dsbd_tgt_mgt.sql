create table sf_cm_dsbd_tgt_mgt
(
    svr_id        varchar(50) not null,
    dsbd_ctg_clc  varchar(2)  not null,
    dsbd_tp_clc   varchar(2)  not null,
    scrn_prnt_seq numeric(3),
    req_port      varchar(5),
    req_uri       varchar(200),
    reg_usr_id    varchar(20),
    reg_stm       date,
    chg_usr_id    varchar(20),
    chg_stm       date,
    constraint sf_cm_dsbd_tgt_mgt_pk
        primary key (svr_id, dsbd_ctg_clc, dsbd_tp_clc)
);

alter table sf_cm_dsbd_tgt_mgt
    owner to safe;

INSERT INTO safe.sf_cm_dsbd_tgt_mgt (svr_id, dsbd_ctg_clc, dsbd_tp_clc, scrn_prnt_seq, req_port, req_uri, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('APDK01', '01', '01', 1, '19930', '/system', 'admin', '2020-07-20', 'admin', '2020-07-20');
INSERT INTO safe.sf_cm_dsbd_tgt_mgt (svr_id, dsbd_ctg_clc, dsbd_tp_clc, scrn_prnt_seq, req_port, req_uri, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('APDK01', '02', '02', 1, '19931', null, 'admin', '2020-07-20', 'admin', '2020-07-20');
INSERT INTO safe.sf_cm_dsbd_tgt_mgt (svr_id, dsbd_ctg_clc, dsbd_tp_clc, scrn_prnt_seq, req_port, req_uri, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('APDK01', '02', '03', 1, '19931', null, 'admin', '2020-07-20', 'admin', '2020-07-20');
INSERT INTO safe.sf_cm_dsbd_tgt_mgt (svr_id, dsbd_ctg_clc, dsbd_tp_clc, scrn_prnt_seq, req_port, req_uri, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('APDK01', '03', '04', 1, '19930', '/kafka', 'admin', '2020-07-20', 'admin', '2020-07-20');
INSERT INTO safe.sf_cm_dsbd_tgt_mgt (svr_id, dsbd_ctg_clc, dsbd_tp_clc, scrn_prnt_seq, req_port, req_uri, reg_usr_id, reg_stm, chg_usr_id, chg_stm) VALUES ('APDK01', '03', '05', 1, '19930', '/health', 'admin', '2020-07-20', 'admin', '2020-07-20');