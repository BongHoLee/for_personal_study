create table sf_cm_api_exec_hst
(
    exec_id    varchar(20) not null
        constraint sf_cm_api_exec_hst_pk
            primary key,
    api_id     varchar(20) not null,
    usr_id     varchar(20) not null,
    exec_stm   date        not null,
    reg_usr_id varchar(20) not null,
    reg_stm    date        not null,
    chg_usr_id varchar(20) not null,
    chg_stm    date        not null
);

alter table sf_cm_api_exec_hst
    owner to safe;

