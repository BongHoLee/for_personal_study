create table sf_cm_dt
(
    dt         varchar(8)  not null
        constraint sf_cm_dt_pk
            primary key,
    dt_clc     varchar(1)  not null,
    hldy_clc   varchar(1),
    expln_ctnt varchar(100),
    reg_usr_id varchar(20) not null,
    reg_stm    date        not null,
    chg_usr_id varchar(20) not null,
    chg_stm    date        not null
);

alter table sf_cm_dt
    owner to safe;

